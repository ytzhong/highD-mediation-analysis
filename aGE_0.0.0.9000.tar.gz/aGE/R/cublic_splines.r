spl.X<-function(x,df=10){
  rk<-function(x,z){
 ((z-0.5)^2-1/12)*((x-0.5)^2-1/12)/4-
 ((abs(x-z)-0.5)^4-(abs(x-z)-0.5)^2/2+7/240)/24
 }
 
 knotnum<-df+2
 knots <- stats::quantile(x, probs = seq(0, 1, length =knotnum ))
 knots <- unique(knots[!knots %in% knots[c(1, knotnum)]]) 
 n<-length(x) 
 X<-outer(x,knots,FUN=rk) 
 return(X)
}