RobustSim<-function(n=n, cov=cov, G=G, EG=XUs, res1=res,  Ts=Ts, n.perm=n.perm, pow=pow, Vinv=Vinv,  model=model, Y=Y,   phi=phi){
 nZ <-ncol(G)
 nX <- ncol(cov) +1
 Xtu <- as.matrix(cbind( rep(1,nrow(EG)), cov, EG )) #add intercept
 A <- t(Xtu) %*% Vinv %*% Xtu
 B <- matrix(0,nrow=(nZ+nX),ncol=(nZ+nX))
 U <- as.vector(t(EG)%*%res1) / phi
 for (i in 1:n){
   B <- B+1/(phi^2)*tcrossprod(Xtu[i,])*(res1[i]^2) }
    B <- B / n
 A <- A / n
 A11inv <- solve(A[1:nX, 1:nX])
 A12 <- A[1:nX, (nX+1):(nZ+nX)]
 A21 <- A[(nX+1):(nZ+nX),1:nX]
 B22 <- B[(nX+1):(nZ+ nX), (nX+1):(nZ+nX)]
 B12 <- B[1:nX, (nX+1):(nZ+nX)]
    B21 <- B[(nX+1):(nZ+nX),1:nX]
 B11 <- B[1:nX, 1:nX]
 A22 <- A[(nX+1):(nZ+ nX), (nX+1):(nZ+nX)]
 CovS <- (A22 - A21 %*% A11inv %*% A12 )
 CovS.edecomp <- eigen(CovS,symmetric=T)
 CovS.ev <- zapsmall(CovS.edecomp$values)
 V22 <- t(CovS.edecomp$vectors %*% (t(CovS.edecomp$vectors) * sqrt(CovS.ev))) #V22 is the standard deviation

 Ts <- rep(NA, length(pow))
    for (j in 1:length(pow)) {
        if (pow[j] < Inf) {
            Ts[j] <- sum((U)^pow[j])
        }
        else {
            Ts[j] <- max(abs(U))
        }
    }

 var <- sum(CovS)
 asyT1 <- (1-pnorm(abs(Ts[1]/sqrt(n)), mean=0, sd=sqrt(var)))*2 #2-sided test
 CovS.ev1 <- CovS.edecomp$values[zapsmall(CovS.edecomp$values)>0]
 asyT2 <- survey::pchisqsum(Ts[2]/n, rep(1, length(CovS.ev1)), CovS.ev1, lower.tail = F, method = "sad")

 pPerm0 <- rep(NA,length(pow))
 T0s <- matrix(NA,n.perm,length(pow))
 for (b in 1:n.perm){
  Us <- rnorm(nZ, 0, 1)
  U0 <- (V22  * sqrt(n)) %*% Us
  for (j in 1:length(pow)){
 if (pow[j] < Inf){ T0s[b,j] = round( sum( (U0)^pow[j]), digits = 8) }
 if (pow[j] == Inf) {T0s[b,j] = round( max(abs(U0)), digits = 8) }
             } }
 T0s <- T0s[complete.cases(T0s),]
 n.perm <- nrow(T0s)
    P0s <- matrix(NA,n.perm,length(pow))
 for (j in 1:length(pow)){
 pPerm0[j] <- round((sum(abs(Ts[j])<=abs(T0s[1:(n.perm-1),j]))+1)/(n.perm), digits = 8)
    P0s[,j] <- (n.perm-rank(abs(T0s[,j]))+1)/(n.perm)
 }
 minp0 <- apply(P0s,1,min)
 fisherp0 <- apply(P0s,1,function(x) sum(log(x)))
 Paspu <- (sum(minp0<=min(pPerm0))+1)/(n.perm+1)
 Pfisher <- (sum(fisherp0<=sum(log(pPerm0)))+1)/(n.perm+1)
 Ts <- c(Ts, min(pPerm0),sum(log(pPerm0)))
 pvs <- c(pPerm0, Paspu,Pfisher, asyT1, asyT2)
 names(pvs) <- c(paste("aGEsm", pow, sep = ""), "aGEsm","aGEsm_fisher","asyT1",'asyT2')
    return(list( pvs = pvs, nperm=n.perm))
      }

GLMMaSPU <- function(tdat=tdat1,model=model,G=G, cov=cov, nc=nc, n=n){
    nZ <- ncol(G)
    if (nc == 1) {
         fixedmod <- "trait ~ cov"
        } else {
         fixedmod <- paste("trait ~", paste(names(tdat)[2:(1 + nc)], collapse = " + "))}
  if (nZ == 1) {
        randommod <- "~ 0 + G"} else {
        randommod <- paste("~ 0 +", paste(names(tdat)[(nc + 2):(1 + nc + nZ)], collapse = " + "))
    }
 if (model == 'binomial'){
    fit1 <- suppressWarnings(MASS::glmmPQL(fixed = as.formula(fixedmod), data = tdat, random = list(id = nlme::pdIdent(as.formula(randommod))), family = model,  verbose = F ))
    pis<-tryCatch(as.numeric(predict(fit1,data=tdat,type='response',level=1)),error=function(c) NA, warning = function(c) NA)
 varc <- tryCatch(nlme::VarCorr(fit1), error=function(c) NA, warning = function(c) NA)
 tau <- ifelse(all(is.na(varc)), NA, as.numeric(varc[1,1])) #because G follows the same distribution
 phi <-  ifelse(all(is.na(varc)), NA, as.numeric(varc[nrow(varc),1]))
 W <- diag(pis*(1-pis))/phi
 } else  if (model=='gaussian'){
 fit1 <- suppressWarnings(MASS::glmmPQL(fixed = as.formula(fixedmod), data = tdat, random = list(id = nlme::pdIdent(as.formula(randommod))), family = model, verbose = F ))
 pis <- tryCatch(as.numeric(predict(fit1,data=tdat,type='response',level=1)),error=function(c) NA, warning = function(c) NA)
 varc <- tryCatch(nlme::VarCorr(fit1), error=function(c) NA, warning = function(c) NA)
 phi <- as.numeric(varc[nrow(varc),1])
 tau <- as.numeric(varc[1,1])
 W <- diag(n)/phi
 }
 return(list(pis=pis, phi=phi, tau=tau, W=W))
 }


#' aGE interaction test
#'
#' @param Y a numeric vector of phenotype values
#' @param G a matrix for all RVs in the test gene or genomic region. The order of rows must match the order of Y. Missing is imputed as 0.
#' @param cov a matrix with first column as the environmental variable to be tested. The order of rows must match the order of Y.
#' @param model "binomial" for binary traits or "gaussian" for quantitative traits.
#' @param pow Gamma set, default=c(1:6,Inf) for rare variants
#' @param n.perm number of simulation to calculate the p-values, default=1000. Can increase to higher value depending on the signficiance level.
#' @param method only have one option: "Simulation", also called Monte Carlo Method.
#' @param nonparaE "T": use cubic splines for the environmental variable to fit the model; "F": use a linear function of the environmental variable to fit the model
#' @param DF: degree of freedom to use in the cubic splines, default=10.
#'
#' @return p-values
#' @export
#'
#' @examples
aGE <- function(Y, G, cov = NULL, model = c("gaussian", "binomial"), pow = c(1:6, Inf), n.perm = 1000,method=c('Simulation'), nonparaE=F ,  DF=10){

    model = match.arg(model, c('gaussian','binomial'))
  method = match.arg(method, c('Simulation'))
  G[is.na(G)] <- 0
  n <- length(Y)
  Ind <- complete.cases(Y) & complete.cases(cov) & complete.cases(G)
  Y <- Y[Ind]
  cov <- cov[Ind,]
  G<-as.matrix(G[Ind,])
  cov <- scale(cov,center=T, scale=T)
  G <- scale(G,center=T, scale=F)
  n <- sum(Ind)
  E <- ME <- cov[,1]
  XUs <- E*G

  if (nonparaE) {ME <- spl.X(x=E,df=DF); cov <- cbind(ME, cov[,-1])}
  tdat1 <- data.frame(cbind(Y=Y,cov))
  pis<-res<-tau<-phi<-W<-NA

  nc <- ncol(cov)
  tdat1 <- data.frame(trait=Y,cov,G,id = rep(1, n))
  nullmodel <- GLMMaSPU(tdat=tdat1,model=model,G=G, cov=cov, nc=nc, n=n)
  pis <- nullmodel$pis; tau<-nullmodel$tau; phi<-nullmodel$phi; W<-nullmodel$W
  res <- as.vector(tdat1$trait - pis)

  if (tau==0) result<-NA else {
  Gw<-W%*%G
  D <- solve( diag(1/tau, ncol(G)) + t(G) %*%  Gw )
  Vinv <- W - Gw %*% D %*% t(Gw)

  if (all(is.na(res))) { return(list(pvs=rep(NA,(length(pow)+4)),nperm=0))} else if (method=='Simulation') {
  s <- sample(1:10^5,1)
  set.seed(s)
  result <- RobustSim(n=n, cov=cov, G=G, EG=XUs, res1=res,  Ts=Ts, n.perm=n.perm, pow=pow, Vinv=Vinv,  model=model, Y=Y,   phi=phi)
  pvs <- result$pvs
}
  rm(Vinv)
  rm(tdat1)
  if (result$nperm < n.perm*0.9)  { warning("more than 10% of error in simulation! ") }
  }
  return(pvs)
}
