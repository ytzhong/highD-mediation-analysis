#'  Function to calculate the Rsq function as a total effect size measure for mediation effect
#'
#' @param p proportion of the training dataset for selecting mediators regarding to the whole dataset, default is set as 1/2
#' @param outcome vector of outcome type of interest; outcome has to follow a Gaussian distribution.
#' @param med matrix of putative mediators
#' @param covar  covariates matrix
#' @param indp vector of independent variable of interest, e.g. environmental variable
#' @param method method used to screen out non-mediators. When no variable selection is required, method='ALL'; otherwise, iterative sure independence screening (SIS) is used for variable selection, i.e., method='iSIS'.
#' @param iter.max maximum number of iteration used in iSIS, default=10 (details see the SIS package)
#' @param nsis Number of pedictors recuited by iSIS
#' @param screening T if filtering mediators based on the strength of indp and mediators as a preprocessing step; F if all putative mediators are included, default=F.
#' @param init.cutoff The percentage of mediators remain after the screening step.
#' @return Output vector consist of Rsq mediated(Rsq.mediated), shared over simple effects (SOS), number of selected mediators (pab), and the Rsqs that used to calculate the Rsq measure: variance of outcome explained by mediator (Rsq.YM), variance of outcome explained by the independent variable (Rsq.YX), and variance of outcome explained by mediator and independent variable (Rsq.YMX)
#' @return Name of selected mediators (select)
#' @export
#' @examples{
#' data(example)
#' attach(example)
#'Rsq.measure(p=1/2, outcome=Y, med=M,covar=Cov,indp=X,method='iSIS', iter.max=1)
#'}
Rsq.measure<-function(p=1/2, outcome,med,covar,indp,method=c('iSIS','ALL'), iter.max=10, nsis=NULL, screening=F,init.cutoff=0.1){

   train <- 1:(nrow(med)*p)
   Med<-apply(med,2,scale,center=T, scale=T)
   indp.std <- scale(indp[train],center=T, scale=T)

   if (!is.null(covar)) {covar <- as.matrix(covar); covar.train <- covar[train,]; covar.test <- covar[-train,]} else {covar.train <- covar.test <- NULL}

   # screen by FDR
   cal_alpha_simple<-function(x){
   data2<-data.frame(Med=x,envir=indp.std, cov=covar.train )
   l<-summary(stats::lm('Med ~.', data=data2))
   invalphap<-(l$coefficients)['envir','Pr(>|t|)']
   return(invalphap)
   }
   # keep the top candidates for ultra high dimensional data
   if(screening) {
   inv.alpha.p<-apply(Med[train,],2, cal_alpha_simple)
   order <- order(stats::p.adjust(inv.alpha.p, method='fdr'))[1:round(init.cutoff *ncol(Med)) ]
   } else order <- 1:ncol(Med)

   Med <- Med[,order]

   #decorrelate X
    orth<-function(x){
    if (is.null(covar.train)) data2 <- data.frame(Med=x,envir=indp.std) else data2<-data.frame(Med=x,envir=indp.std, cov=covar.train )
    l<-summary(stats::lm('Med ~.', data=data2))
    res<-stats::residuals(l)
    return(res)
    }
   Med_res<-apply(Med[train,],2, orth)
   Med_res<-apply(Med_res,2,scale,center=T, scale=T)

   if (is.null(covar.train))  tdat <- data.frame(y=outcome[train], x=indp.std) else tdat <- data.frame(y=outcome[train], x=indp.std, cov=covar.train)

   f0 <- stats::lm(y~., data=tdat)
   res <- stats::residuals(f0)

   # iterative SIS is suggested for mediation analysis,
   if (method=='iSIS'){
    if (is.null(nsis)) {N <- length(res);  nsis=N/log(N)}
   model1 <- invisible(SIS::SIS(x=Med_res, y=res, family='gaussian',tune='bic',  seed=1234, penalty='MCP',nsis=nsis, iter.max=iter.max))
   pab <- length(model1$ix)
   select <- model1$ix
   } else if (method=='ALL'){
   select <- 1:ncol(Med)
   pab <- ncol(Med)
   }

    #in the testing data
   if (!is.null(covar.test)) {
     tdat <- data.frame(y=outcome[-train], cov=covar.test)
   f0 <- stats::lm(y~. , data=tdat)
   res <- stats::residuals(f0)} else res <- outcome[-train]
   SST=sum((res-mean(res))^2)
   MST=SST/(length(res)-1)

   indp.std <- scale(indp[-train],center=T, scale=T)

   testing <- data.frame(pheno=res,  envir=indp.std)
   f3<-tryCatch(stats::lm(pheno~envir, data=testing), error=function(c) NA, warning=function(c) NA)
   if (all(is.na(f3))) total<-Rsq.YX<-NA else {
    Rsq.YX=summary(f3)$adj.r.squared #******
   total<-f3$coefficients[2]
   names(total) <-NULL }
   sy<-stats::sd(res,na.rm=T)

   if (pab==0) { #corrected by Oct 9th, 2018
   output <- c(Rsq.mediated=0,SOS=0, pab=0, Rsq.YM=0, Rsq.YX=Rsq.YX, Rsq.YMX=Rsq.YX, total=total, abprod=0)
   return(list(output=output, select=NULL))
   } else {

   Med <- Med[-train,select,drop=F]

   #Y~M+X
   Kins <- as.matrix(Med)%*%t(as.matrix(Med))
   colnames(Kins) <- rownames(Kins) <- 1:nrow(testing)
   testing$id <- 1:nrow(testing)
   fit1 <- tryCatch(GMMAT::glmmkin(res~envir, id='id', data=testing, kins=Kins, family=stats::gaussian(link='identity')), error=function(c) NA)
   if (all(is.na(fit1))) { tau<-phi<-direct<-NA } else {
    if (fit1$converged) {tau<-fit1$theta[2] ; phi<-fit1$theta[1];  direct<-fit1$coefficients[2]; } else tau<-phi<-direct<-NA }
   Rsq.YMX <- 1-phi/MST #******

   #Y~M
   fit2 <- tryCatch(GMMAT::glmmkin(res~1, data=testing, kins=Kins,id='id', family=stats::gaussian(link='identity')), error=function(c) NA)
   if (all(is.na(fit2))) { tau2<-phi2<-NA } else {
   if (fit2$converged) {tau2<-fit2$theta[2] ; phi2=fit2$theta[1]} else tau2<-phi2<-NA }
   Rsq.YM <- 1-phi2/MST

   Rsq.mediated <- Rsq.YM+Rsq.YX-Rsq.YMX
   SOS <-  Rsq.mediated/Rsq.YX
   abproduct= as.numeric(total-direct)
   output <- c(Rsq.mediated=Rsq.mediated,  SOS=SOS, pab=pab, Rsq.YM=Rsq.YM, Rsq.YX=Rsq.YX, Rsq.YMX=Rsq.YMX,  total=total,  abprod=abproduct )

    if (!is.null(colnames(Med))) select <- 'column name of Mediators are not specified' else select <- colnames(Med)

   return(list(output=output, select=select))
}
}


