## ---- echo=FALSE---------------------------------------------------------
require(RsqMed)
str(example)

## ---- warning=FALSE------------------------------------------------------
require('RsqMed')
Rsq.measure(p=1/2, outcome=example$Y,med=example$M,covar=example$Cov,indp=example$X, method='ISIS',iter.max=2)

## ---- message=FALSE, warning=FALSE---------------------------------------
require('RsqMed')
CI.Rsq.measure(p=1/2, outcome=example$Y,med=example$M,covar=example$Cov,indp=example$X, method='ISIS',iter.max=2, B=3)

