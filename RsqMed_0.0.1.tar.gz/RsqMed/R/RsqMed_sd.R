#' Functions to generate the confidence interval of the Rsq measure using bootstrap 
#'
#' @param p proportion of the training dataset regarding to the whole dataset, default is set as 1/2
#' @param outcome vector of outcome of interest; continous only (best performed when it is normal distributed)
#' @param med matrix of potential mediators
#' @param covar  covariates matrix
#' @param indp vector of independent variable
#' @param method method used to screen out non-mediators. When no variable selection is required, method='All'; otherwise, wse ISIS or SIS to do variable selection, i.e., method='ISIS' or method='SIS'
#' @param B number of bootstrap sample, default is 100
#' @param ... options, e.g., options used in SIS
#' @return A table that generate the 95 percent confidence interval of Rsq measure (Rsq.mediated), shared over simple effects (SOS), number of mediators selected (pab), variance of outcome explained by mediator (Rsq.YM), variance of outcome explained by the independent variable (Rsq.YX), and variance of outcome explained by mediator and independent variable (Rsq.YMX)
#' @export
#' @examples \dontrun{CI.Rsq.measure(p=1/2, outcome=example$Y,med=example$M,covar=example$Cov,indp=example$X, method='ISIS',iter.max=2, B=3,verbose=F)}
CI.Rsq.measure <- function( p=1/2, outcome,med,covar,indp, method=c('ISIS','SIS','All'),B=100,...){
output <- matrix(NA, nrow=B, ncol=6)
for (i in 1:B){
set.seed(i) #updated Oct 10, 2018
N <- length(outcome)
ID <- sample(1:N,N, replace=T)
outcome_cl <-outcome[ID]
med_cl <-med[ID,]
covar_cl <-covar[ID,]
indp_cl <-indp[ID]
output[i,]<-RsqMed::Rsq.measure(p=p,  outcome=outcome_cl ,med=med_cl ,covar=covar_cl, indp=indp_cl , method=method,...)
}
CI <- apply(output,2,stats::quantile,probs=c(0.025,0.975),na.rm=T)
colnames(CI) <- colnames(output) <- c('Rsq.mediated','SOS','pab','Rsq.YM','Rsq.YX','Rsq.YMX')
rownames(CI) <- c('2.5%','97.5%')
return(CI)
}
