#'  Function to calculate the Rsq function as a total effect size measure for mediation effect
#'
#' @param p proportion of the training dataset regarding to the whole dataset, default is set as 1/2
#' @param outcome vector of outcometype of interest; continous only (best performed when it is normal distributed)
#' @param med matrix of potential mediators
#' @param covar  covariates matrix
#' @param indp vector of independent variable of interest, e.g. environmental variable
#' @param method method used to screen out non-mediators. When no variable selection is required, method='All'; otherwise, wse ISIS or SIS to do variable selection, i.e., method='ISIS' or method='SIS; ISIS is slower than SIS when n and p is large. Note if variable selection is performed, then the data is randomly split into two parts. The first part is the training dataset for variable selection and the second part is used for inference 
#' @param ... other options, e.g., options used in SIS
#' @return Output vector consist of Rsq mediated(Rsq.mediated), shared over simple effects (SOS), number of selected mediators (pab), and the Rsqs that used to calculate the Rsq measure: variance of outcome explained by mediator (Rsq.YM), variance of outcome explained by the independent variable (Rsq.YX), and variance of outcome explained by mediator and independent variable (Rsq.YMX) 
#' @export
#' @examples \dontrun{Rsq.measure(p=1/2, outcome=example$Y,med=example$M,covar=example$Cov,indp=example$X, method='ISIS',iter.max=2)}


Rsq.measure<-function(p=1/2, outcome,med,covar,indp, method=c('ISIS','SIS','All'),...){
  
   #first step run variable selection
   train <- 1:round(nrow(med)*p)
   
   #standardized Med and independent variable
   Med<-apply(med,2,scale,center=T, scale=T)
   indp.std <- scale(indp[train],center=T, scale=T)
   outcome_n <- outcome[train]
   covar_train <- covar[train,]
   
   #regress the covariates out to get residual
   f0 <- stats::lm(outcome_n~covar_train)
   res <- f0$residuals
   f3 <- tryCatch(stats::lm(res~indp.std+1), error=function(c) NA)
   Rsq.YX <- summary(f3)$r.squared
   
   if (method!='All') {
   X <- as.matrix(cbind(indp.std,Med[train,]))
   Y <- res
   if (method=='ISIS') model1 <- invisible(SIS::SIS(x=X, y=Y, family='gaussian',tune='bic',  seed=1234, penalty='MCP',...))
   if (method=='SIS') model1 <- invisible(SIS::SIS(x=X, y=Y, family='gaussian',tune='bic',  seed=1234, penalty='MCP', iter=F,...))
   
   pab<-length(which(model1$ix!=1))
   select <- (model1$ix[which(model1$ix!=1)]-1)
   #EnrInc <- which(model1$ix==1)
   } else {
   pab<-ncol(Med)
   select <- seq(1,pab)
   #EnrInc <- 1
   train <- nrow(med) + 1
   }   
   
   if (pab==0) { #corrected by Oct 9th, 2018
   output <- c(Rsq.mediated=0,SOS=0, pab=0, Rsq.YM=0, Rsq.YX=Rsq.YX, Rsq.YMX=Rsq.YX)
   return(output)
   }else {
   #in the second half
   Med <- Med[-train,select,drop=F]
   indp.std <- scale(indp[-train],center=T, scale=T)
   outcome_n <- outcome[-train]
   covar_test <- covar[-train,]
   
   f0 <- stats::lm(outcome_n ~ covar_test) 
   res <- f0$residuals
   
   SST <- sum((res-mean(res))^2)
   MST <- SST/(nrow(Med)-1)
   
   #Y~M+X
   Kins <- as.matrix(Med)%*%t(as.matrix(Med))	
   Kins.1 <- indp.std%*%t(indp.std)
   Kins.2 <- list(Kins,Kins.1)
   testing <- data.frame(cbind(res=res, indp.std=indp.std))
   fit1 <- tryCatch(GMMAT::glmmkin(res~1, data=testing, kins=Kins.2, family=gaussian(link='identity')), error=function(c) NA) 
   if (all(is.na(fit1))) { tau<-phi<-direct<-NA } else {
    if (fit1$converged) {tau<-fit1$theta[2] ; phi<-fit1$theta[1];  direct<-fit1$coefficients[2]} else tau<-phi<-direct<-NA }
   Rsq.YMX <- 1-phi/MST

   #Y~M	
   fit2 <- tryCatch(GMMAT::glmmkin(res~1, data=testing, kins=Kins, family=gaussian(link='identity')), error=function(c) NA) 
   if (all(is.na(fit2))) { tau2<-phi2<-NA } else {
   if (fit2$converged) {tau2<-fit2$theta[2] ; phi2=fit2$theta[1]; } else tau2<-phi2<-NA }
   Rsq.YM <- 1-phi2/MST
   

   #Y~X
   f3 <- tryCatch(stats::lm(res~indp.std+1), error=function(c) NA)
   Rsq.YX <- summary(f3)$r.squared
   total <- f3$coefficients[1]
 
   Rsq.mediated <- Rsq.YM+Rsq.YX-Rsq.YMX
   SOS <-  Rsq.mediated/Rsq.YX
   output <- c(Rsq.mediated=Rsq.mediated,SOS=SOS, pab=pab, Rsq.YM=Rsq.YM, Rsq.YX=Rsq.YX, Rsq.YMX=Rsq.YMX)
   return(output)
}
}
