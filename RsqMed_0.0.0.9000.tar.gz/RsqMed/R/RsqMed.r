#' Title Function to calculate the Rsq function
#'
#' @param p proportion of the training dataset regarding to the whole dataset, default is set as 1/2
#' @param pheno vector of phenotype of interest; continous only (best performed when it is normal distributed)
#' @param med matrix of potential mediators
#' @param covar  baseline covariates matrix
#' @param envir vector of environment of interest
#' @param ISIS whether use ISIS to do variable selection
#' @param seed random seed 
#'
#' @return output vector consist of Rsq mediated, number of selected mediators, Rsq.YM, Rsq.YX, and Rsq.YMX
#' @export
#'
#' @examples  

Rsq.measure<-function( p=1/2, pheno,med,covar,envir, ISIS=F,seed=1234){
  
  #first step run variable selection
  train <- 1:round(nrow(med)*p)

  #standardized Med
  Med<-apply(med,2,scale,center=T, scale=T)
  envir.std <- scale(envir[train],center=T, scale=T)
  pheno_n <- pheno[train]
  covar_train <- covar[train,]

  #regress the covariates out to get residual
  f0<-lm(pheno_n~covar_train)
  res<-f0$residuals
  f3<-tryCatch(lm(res~envir.std+1), error=function(c) NA)
  Rsq.YX<-summary(f3)$r.squared

  if (ISIS) {
    X<-as.matrix(cbind(envir.std,Med[train,]))
    Y<-res
    model1<-SIS::SIS(x=X, y=Y, family='gaussian',tune='bic',  seed=seed, penalty='MCP',  iter.max=5)
    pab<-length(which(model1$ix!=1))
    select<- (model1$ix[which(model1$ix!=1)]-1)
    EnrInc <- which(model1$ix==1)
  } else {
    pab<-ncol(Med)
    select <- seq(1,pab)
    EnrInc <- 1
    train <- nrow(med) + 1
  }

  if (ncol(Med)==0) {
    output<-c(Rsq.mediated=0,pab=0, Rsq.YM=NA, Rsq.YX=Rsq.YX, Rsq.YMX=NA, EnrInc=EnrInc)
    return(output)
  }else {
    #in the second half
    Med<-Med[-train,select,drop=F]
    envir.std<-scale(envir[-train],center=T, scale=T)
    pheno_n <- pheno[-train]
    covar_test <- covar[-train,]

    f0<-lm(pheno_n ~ covar_test)
    res<-f0$residuals

    SST=sum((res-mean(res))^2)
    MST=SST/(nrow(Med)-1)

    #Y~M+X
    Kins<-as.matrix(Med)%*%t(as.matrix(Med))
    Kins.1<-envir.std%*%t(envir.std)
    Kins.2<-list(Kins,Kins.1)
    testing <- data.frame(cbind(res=res, envir.std=envir.std))
    fit1<-tryCatch(GMMAT::glmmkin(res~1, data=testing, kins=Kins.2, family=gaussian(link='identity')), error=function(c) NA)
    if (all(is.na(fit1))) { tau<-phi<-direct<-NA } else {
      if (fit1$converged) {tau<-fit1$theta[2] ; phi=fit1$theta[1];  direct<-fit1$coefficients[2]} else tau<-phi<-direct<-NA }
    Rsq.YMX<-1-phi/MST

    #Y~M
    fit2<-tryCatch(GMMAT::glmmkin(res~1, data=testing, kins=Kins, family=gaussian(link='identity')), error=function(c) NA)
    if (all(is.na(fit2))) { tau2<-phi2<-NA } else {
      if (fit2$converged) {tau2<-fit2$theta[2] ; phi2=fit2$theta[1]; } else tau2<-phi2<-NA }
    Rsq.YM<-1-phi2/MST


    #Y~X
    f3<-tryCatch(lm(res~envir.std+1), error=function(c) NA)
    Rsq.YX<-summary(f3)$r.squared
    total<-f3$coefficients[1]

    Rsq.mediated=Rsq.YM+Rsq.YX-Rsq.YMX
    output<-c(Rsq.mediated=Rsq.mediated,pab=pab, Rsq.YM=Rsq.YM, Rsq.YX=Rsq.YX, Rsq.YMX=Rsq.YMX)
    return(output)
  }
}
