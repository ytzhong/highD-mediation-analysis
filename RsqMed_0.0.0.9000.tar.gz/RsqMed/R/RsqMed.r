#' Title Function to calculate the Rsq function
#'
#' @param p proportion of the training dataset regarding to the whole dataset, default is set as 1/2
#' @param outcome vector of outcometype of interest; continous only (best performed when it is normal distributed)
#' @param med matrix of potential mediators
#' @param covar  baseline covariates matrix
#' @param indp vector of indponment of interest
#' @param method whether use ISIS or SIS to do variable selection, or simply including all mediators. ISIS is slower than SIS when n and p is large.
#' @param seed random seed 
#'
#' @return output vector consist of Rsq mediated(Rsq.mediated), shared over simple effects (SOS), number of selected mediators (pab), and the Rsqs that used to calculate the Rsq measure: Rsq.YM, Rsq.YX, and Rsq.YMX 
#' @export
#'
#' @examples  written in the introduction


Rsq.measure<-function( p=1/2, outcome,med,covar,indp, method=c('ISIS','SIS','All') ,seed=1234){
   #first step run variable selection
   train <- 1:round(nrow(med)*p)
   
   #standardized Med
   Med<-apply(med,2,scale,center=T, scale=T)
   indp.std <- scale(indp[train],center=T, scale=T)
   outcome_n <- outcome[train]
   covar_train <- covar[train,]
   
   #regress the covariates out to get residual
   f0 <- lm(outcome_n~covar_train)
   res <- f0$residuals
   f3 <- tryCatch(lm(res~indp.std+1), error=function(c) NA)
   Rsq.YX <- summary(f3)$r.squared
   
   if (method!='All') {
   X <- as.matrix(cbind(indp.std,Med[train,]))
   Y <- res
   if (method=='ISIS') model1 <- SIS::SIS(x=X, y=Y, family='gaussian',tune='bic',  seed=seed, penalty='MCP',  iter.max=5)
   if (method=='SIS') model1 <- SIS::SIS(x=X, y=Y, family='gaussian',tune='bic',  seed=seed, penalty='MCP',  iter=F)
   
   pab<-length(which(model1$ix!=1))
   select <- (model1$ix[which(model1$ix!=1)]-1)
   EnrInc <- which(model1$ix==1)
   } else {
   pab<-ncol(Med)
   select <- seq(1,pab)
   EnrInc <- 1
   train <- nrow(med) + 1
   }   
   
   if (ncol(Med)==0) {
   output <- c(Rsq.mediated=0,SOS=0, pab=0, Rsq.YM=NA, Rsq.YX=Rsq.YX, Rsq.YMX=NA)
   return(output)
   }else {
   #in the second half
   Med <- Med[-train,select,drop=F]
   indp.std <- scale(indp[-train],center=T, scale=T)
   outcome_n <- outcome[-train]
   covar_test <- covar[-train,]
   
   f0 <- lm(outcome_n ~ covar_test) 
   res <- f0$residuals
   
   SST <- sum((res-mean(res))^2)
   MST <- SST/(nrow(Med)-1)
   
   #Y~M+X
   Kins <- as.matrix(Med)%*%t(as.matrix(Med))	
   Kins.1 <- indp.std%*%t(indp.std)
   Kins.2 <- list(Kins,Kins.1)
   testing <- data.frame(cbind(res=res, indp.std=indp.std))
   fit1 <- tryCatch(GMMAT::glmmkin(res~1, data=testing, kins=Kins.2, family=gaussian(link='identity')), error=function(c) NA) 
   if (all(is.na(fit1))) { tau<-phi<-direct<-NA } else {
    if (fit1$converged) {tau<-fit1$theta[2] ; phi<-fit1$theta[1];  direct<-fit1$coefficients[2]} else tau<-phi<-direct<-NA }
   Rsq.YMX <- 1-phi/MST

   #Y~M	
   fit2 <- tryCatch(GMMAT::glmmkin(res~1, data=testing, kins=Kins, family=gaussian(link='identity')), error=function(c) NA) 
   if (all(is.na(fit2))) { tau2<-phi2<-NA } else {
   if (fit2$converged) {tau2<-fit2$theta[2] ; phi2=fit2$theta[1]; } else tau2<-phi2<-NA }
   Rsq.YM <- 1-phi2/MST
   

   #Y~X
   f3 <- tryCatch(lm(res~indp.std+1), error=function(c) NA)
   Rsq.YX <- summary(f3)$r.squared
   total <- f3$coefficients[1]
 
   Rsq.mediated <- Rsq.YM+Rsq.YX-Rsq.YMX
   SOS <-  Rsq.mediated/Rsq.YX
   output <- c(Rsq.mediated=Rsq.mediated,SOS=SOS, pab=pab, Rsq.YM=Rsq.YM, Rsq.YX=Rsq.YX, Rsq.YMX=Rsq.YMX)
   return(output)
}
}


#' Title Functions to generate the confidence interval of the Rsq measure using bootstrap
#'
#' @param p proportion of the training dataset regarding to the whole dataset, default is set as 1/2
#' @param outcome vector of outcometype of interest; continous only (best performed when it is normal distributed)
#' @param med matrix of potential mediators
#' @param covar  baseline covariates matrix
#' @param indp vector of indponment of interest
#' @param ISIS whether use ISIS to do variable selection
#' @param seed random seed
#' @param B number of bootstrap sample
#'
#' @return A table that generate the confidence interval of Rsq measure (Rsq.mediated), shared over simple effects (SOS), number of mediators selected (pab) and variance of outcome explained by indp (Rsq.YX)
#' @export
#'
#' @examples
CI.Rsq.measure <- function( p=1/2, outcome,med,covar,indp, method=c('ISIS','SIS','All'),seed=1234, B){
output <- matrix(NA, nrow=B, ncol=6)
for (i in 1:B){
N <- length(outcome)
ID <- sample(1:N,N, replace=T)
outcome<-outcome[ID]
med<-med[ID,]
covar<-covar[ID,]
indp<-indp[ID]
output[i,]<-RsqMed::Rsq.measure(p=p,  outcome=outcome,med=med,covar=covar,indp=indp, method=method,seed=seed)
}
CI <- apply(output,2,quantile,probs=c(0.025,0.975),na.rm=T)
colnames(CI) <- c('Rsq.mediated','SOS','pab','Rsq.YM','Rsq.YX','Rsq.YMX')
CI <- CI[,c('Rsq.mediated','SOS','pab','Rsq.YX')]
return(CI)
}
